{-# LANGUAGE TypeApplications #-}

module Main where

import System.IO

data User = User {
    ulogin :: String
  , uage   :: Int
  , ubio   :: String
  }
  deriving Show

mSplit :: Eq a => a -> [a] -> [[a]]
mSplit _  [] = [[]]
mSplit c arr = takeWhile (/=c) arr : mSplit c (drop 1 $ dropWhile (/= c) arr)

main :: IO ()
main = do
  hSetBuffering stdout NoBuffering

  usersS <- readFile usersPath
  let
    usersL = lines usersS
    uSplit = mSplit ';'
    users  = map (\usr -> User (uSplit usr !! 0) (read $ uSplit usr !! 1) (uSplit usr !! 2)) usersL

  putStrLn "---APP---"
  putStr "(R)egister/(L)ogin (or :q): "
  typeApp <- getLine

  case typeApp of
    "R"  -> registerForm users
    "L"  -> loginForm users
    ":q" -> pure ()
    _    -> do
             putStrLn "Err"
             main

registerForm :: [User] -> IO ()
registerForm accountList = do
  putStrLn "---REGISTRATION---"
  putStr "Login (or :q): "
  login <- getLine

  let
    findUser = filter (\x -> login == ulogin x) accountList

  if login == ":q" then
    main
  else if length findUser /= 0 then do
    putStrLn $ "Login is used"
    registerForm accountList
  else do
    putStr "Enter age: "
    age <- getLine

    if not $ checkAge $ read age then do
      putStrLn $ "Age incorrect"
      registerForm accountList
    else do
      putStrLn $ "Register success"
      appendFile usersPath $ concat ["\n", login, ";", age, ";"]

      putStrLn "---CHAT---"
      chatForm accountList (User login (read age) "")


loginForm :: [User] -> IO ()
loginForm accountList = do
  putStrLn "---LOGIN---"
  putStr "Login: "
  login <- getLine

  let
    findUser = filter (\x -> login == ulogin x) accountList

  if length findUser /= 0 then do
    putStrLn $ "Login success"
    putStrLn "---CHAT---"
    chatForm accountList (head findUser)
  else do
    putStrLn $ "No account"
    main


chatForm :: [User] -> User -> IO ()
chatForm accountList user = do
  putStr "Message (or :q): "
  messageData <- getLine

  chatS <- readFile chatPath

  let
    msgCom = words messageData
    chat = lines chatS

  case msgCom !! 0 of
    ":q" -> pure ()
    ":h" -> mapM_ putStrLn showHelp
    ":a" -> mapM_ putStrLn chat
    ":i" -> putStrLn $ show user
    ":r" -> putStrLn $ concat [ulogin user, " [R]> ", (reverse . unwords . drop 1) msgCom]
    ":c" -> putStrLn $ concat [ulogin user, " [C]> "
                              ,show @Int $ read (msgCom !! 1) + read (msgCom !! 2)]
    ":l" -> putStrLn $ show $
              if (length msgCom /= 1) then
                filter (and . zipWith (==) (msgCom !! 1) . ulogin) $ accountList
              else
                accountList
    _    -> putStrLn $ ulogin user ++ "> " ++ messageData

  if msgCom !! 0 == ":q" then
    pure ()
  else
    chatForm accountList user



usersPath :: FilePath
chatPath  :: FilePath
usersPath  = "data/users"
chatPath   = "data/chat"

showHelp :: [String]
showHelp =  [ "---HELP---"
            , ":h for help"
            , ":a for show chat"
            , ":i for info user"
            , ":q for exit"
            , ":r <msg> to reverse"
            , ":c <a> <b> to a + b"
            , ":l <login> to search"
            ]

checkAge :: Int -> Bool
checkAge x = (x > 17) && (x < 80)
